"""cone_follow 단순 폐루프 시뮬레이션 (ROS 없음).

두 줄 콘 통로(약간 휜 직선)를 무작위로 만들고, 라이다를 광선으로 흉내 내서 ConeFollower + ModeMachine 을 돌린다.
조향은 1차 지연 + 배율 오차, 라이다는 0.5도 간격 + 거리 잡음. 차체 직사각형과 콘 받침 원이 닿으면 접촉.

  python3 -I test/sim_cone_follow.py [횟수] [seed] [hard]
"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'jetracer_ros2'))
import cone_follow as C  # noqa: E402

CONE_R_SCAN = 0.035     # 라이다 높이에서 콘 반지름
CONE_R_BASE = 0.05      # 받침 반지름 (접촉 판정)
HARD = 'hard' in sys.argv   # 좁은 통로·큰 시작 오차·큰 조향 오차


def make_course(rng):
    width = rng.uniform(0.40, 0.48) if HARD else rng.uniform(0.42, 0.60)
    spacing = rng.uniform(0.30, 0.45)
    length = rng.uniform(2.0, 3.0)
    amp = rng.uniform(-0.4, 0.4) if HARD else rng.uniform(-0.25, 0.25)          # 곡률 최대 0.25 (반지름 4 m 이상)
    period = rng.uniform(2.0, 5.0)
    phase = rng.uniform(0, 2 * math.pi)
    ds = 0.01
    s = np.arange(0, length + 1.5, ds)
    k = amp * np.sin(2 * math.pi * s / period + phase)
    k[s > length] = 0.0
    th = np.cumsum(k) * ds
    x = np.cumsum(np.cos(th)) * ds
    y = np.cumsum(np.sin(th)) * ds
    cones = []
    for sc in np.arange(0, length + 1e-9, spacing):
        i = int(sc / ds)
        nx, ny = -math.sin(th[i]), math.cos(th[i])
        for side in (1, -1):
            j = rng.normal(0, 0.015, 2)
            cones.append((x[i] + side * width / 2 * nx + j[0], y[i] + side * width / 2 * ny + j[1]))
    return np.array(cones), (s, x, y, th), length, width


def raycast(pose, cones, p, rng):
    px, py, pth = pose
    lx = px + p.lidar_x * math.cos(pth)
    ly = py + p.lidar_x * math.sin(pth)
    ang = np.arange(-math.pi, math.pi, math.radians(0.5))
    world = ang + pth
    dx, dy = np.cos(world), np.sin(world)
    r = np.full(len(ang), np.inf)
    for cx, cy in cones:
        ox, oy = cx - lx, cy - ly
        b = ox * dx + oy * dy
        c = ox * ox + oy * oy - CONE_R_SCAN ** 2
        disc = b * b - c
        hit = (disc >= 0) & (b > 0)
        t = b - np.sqrt(np.where(hit, disc, 0))
        r = np.where(hit & (t < r), t, r)
    r = np.where(np.isfinite(r), r + rng.normal(0, 0.01, len(r)), np.inf)
    drop = rng.random(len(r)) < 0.03
    r[drop] = np.inf
    return float(ang[0]), math.radians(0.5), r


def contact(pose, cones, p):
    px, py, pth = pose
    c, s = math.cos(pth), math.sin(pth)
    dx, dy = cones[:, 0] - px, cones[:, 1] - py
    lx = c * dx + s * dy
    ly = -s * dx + c * dy
    qx = np.clip(lx, -p.car_rear, p.car_front)
    qy = np.clip(ly, -p.car_half_width, p.car_half_width)
    d = np.hypot(lx - qx, ly - qy)
    return float(d.min()), int(np.sum(d < CONE_R_BASE))


def run(rng, verbose=False):
    p = C.Params()
    cones, (cs, cx, cy, cth), length, width = make_course(rng)
    f = C.ConeFollower(p)
    m = C.ModeMachine(p)
    # 시작: 첫 콘 0.7 m 앞, 옆 오차·방향 오차
    pose = np.array([-0.7 - p.car_front, rng.uniform(-0.06, 0.06) * (2 if HARD else 1), math.radians(rng.uniform(-8, 8) * (2 if HARD else 1))])
    k_act, gain_err = 0.0, (rng.uniform(0.7, 1.3) if HARD else rng.uniform(0.85, 1.15))
    dt, t = 0.05, 0.0
    plan, stop_time, max_stop, touched = C.Plan(), 0.0, 0.0, set()
    min_clear = 9.0
    end_x_goal = cx[int(length / 0.01)] + 0.6
    while t < 60:
        if int(round(t / dt)) % 2 == 0:       # 라이다 10 Hz
            a0, inc, r = raycast(pose, cones, p, rng)
            pts, _ = C.scan_points(a0, inc, r, p)
            plan = f.update(pts, t)
            m.step(plan)
        if m.mode == 'CONE':
            v, k = plan.v, plan.k
        else:                                  # 차선 주행 흉내: 들어가기 전은 y=0 직선, 나온 뒤는 마지막 방향 직진
            v = 0.20
            if m.mode == 'LANE':
                L = 0.5
                ey = -(pose[1] + L * math.sin(pose[2]))
                k = float(np.clip(2 * ey / L ** 2, -1.5, 1.5))
            else:
                k = 0.0
        k_act += (k * gain_err - k_act) * min(1.0, dt / 0.15)
        pose[0] += v * math.cos(pose[2]) * dt
        pose[1] += v * math.sin(pose[2]) * dt
        pose[2] += v * k_act * dt
        dmin, n = contact(pose, cones, p)
        min_clear = min(min_clear, dmin - CONE_R_BASE)
        if n:
            touched.add(n)
        stop_time = stop_time + dt if v < 1e-3 else 0.0
        max_stop = max(max_stop, stop_time)
        t += dt
        if pose[0] > end_x_goal and m.mode == 'DONE':
            break
    ok = pose[0] > end_x_goal and m.mode == 'DONE' and not touched and max_stop < 2.0
    if verbose:
        print(f'  폭 {width:.2f} 길이 {length:.1f} 끝 {"OK" if ok else "FAIL"} 모드 {m.mode} 시간 {t:.1f}s '
              f'최소여유 {min_clear * 100:.1f}cm 접촉 {bool(touched)} 최장정지 {max_stop:.1f}s 추정폭 {f.width:.2f}')
    return ok, bool(touched), max_stop, min_clear, t, m.mode


def main():
    nums = [a for a in sys.argv[1:] if a.isdigit()]
    n = int(nums[0]) if nums else 100
    seed = int(nums[1]) if len(nums) > 1 else 0
    rng = np.random.default_rng(seed)
    res = [run(rng, verbose=n <= 10) for _ in range(n)]
    ok = sum(r[0] for r in res)
    touch = sum(r[1] for r in res)
    stall = sum(r[2] >= 2.0 for r in res)
    notdone = sum(r[5] != 'DONE' for r in res)
    clears = np.array([r[3] for r in res])
    times = np.array([r[4] for r in res])
    print(f'{n}회: 통과 {ok}, 접촉 {touch}, 2초 이상 정지 {stall}, 출구 미전환 {notdone}, '
          f'최소여유 중앙 {np.median(clears) * 100:.1f}cm / 최저 {clears.min() * 100:.1f}cm, 시간 중앙 {np.median(times):.1f}s')
    return 0 if ok == n else 1


if __name__ == '__main__':
    sys.exit(main())
