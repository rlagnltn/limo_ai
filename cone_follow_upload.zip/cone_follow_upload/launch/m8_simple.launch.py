"""라바콘(M8) 단순 시험: 차선 주행(simple_lane) -> 두 줄 콘 가운데 선 따라가기(cone_follow) -> 다시 차선 주행.

하드웨어(jetracer_teleop.launch.py)는 따로 한 번만 켠다. 매니저는 쓰지 않는다:
  simple_lane --(inference/cmd_vel)--> cone_follow_node --(/cmd_vel)--> bridge -> /limo/ack_cmd

  ros2 launch jetracer_ros2 m8_simple.launch.py                 콘 입구 앞 차로에서 시작
  ros2 launch jetracer_ros2 m8_simple.launch.py start_in_cone:=true   이미 콘 안에서 시작
  인자: record:=false, speed:=0.15, width:=0.50 (통로 폭 처음 값, 콘 중심 사이)
"""
import os
from datetime import datetime

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    bag = os.path.expanduser('~/bag_m8_simple_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    topics = ['/scan', '/odom', '/limo_status', '/camera/color/image_raw/compressed',
              '/camera/color/camera_info', '/inference/cmd_vel', '/cmd_vel', '/limo/ack_cmd',
              '/cone_follow/state', '/mission/event', '/yolo/debug/compressed', '/perception/detections']
    return LaunchDescription([
        DeclareLaunchArgument('start_in_cone', default_value='false', choices=['true', 'false']),
        DeclareLaunchArgument('record', default_value='true', choices=['true', 'false']),
        DeclareLaunchArgument('speed', default_value='0.15'),
        DeclareLaunchArgument('width', default_value='0.50'),
        DeclareLaunchArgument('bag', default_value=bag),
        ExecuteProcess(cmd=['ros2', 'bag', 'record', '-o', LaunchConfiguration('bag'), *topics],
                       output='screen', condition=IfCondition(LaunchConfiguration('record'))),
        Node(package='jetracer_ros2', executable='simple_lane', output='screen', emulate_tty=True,
             arguments=['drive', '--topic', 'inference/cmd_vel']),
        Node(package='jetracer_ros2', executable='cone_follow_node', output='screen', emulate_tty=True,
             parameters=[{
                 'start_in_cone': ParameterValue(LaunchConfiguration('start_in_cone'), value_type=bool),
                 'v_cone': ParameterValue(LaunchConfiguration('speed'), value_type=float),
                 'width_init': ParameterValue(LaunchConfiguration('width'), value_type=float),
             }]),
    ])
