# M8 라바콘: 두 줄 콘 가운데 선 따라가기 (cone_follow)

2026-11-18 실차에서 콘 구간 통과 확인. 라이다(/scan)만 사용.

## 동작
1. 라이다 점을 묶어(8 cm) 폭 20 cm 이하 묶음을 콘으로 본다.
2. 직전 가운데 선 기준으로 왼쪽 / 오른쪽 줄로 나누고, 각 줄을 직선으로 맞춘다 (가까운 콘에 무게).
3. 두 줄 가운데 선 (한 줄만 보이면 그 줄에서 통로 폭 절반 띄움, 통로 폭은 계속 측정).
4. 가운데 선 0.45 m 앞 점을 pure pursuit, 0.15 m/s (한 줄만 보일 때 0.11). 최대 곡률 1.9 (회전반경 약 0.53 m).
5. 25 cm 차체 스윕(+2 cm 여유)에 콘이 걸리면 가장 가까운 안 막힌 곡률. 전부 막히면 정지, 1.5 초 넘으면 여유 0 으로 재탐색.
6. 모드: LANE(차선 명령 그대로) -> 1.1 m 안 양쪽 줄 3 스캔 연속 -> CONE -> 앞 0.9 m 콘 없음 5 스캔 -> DONE(다시 차선).

## 파일 (jetracer_ros2 패키지 안 같은 위치에 넣기)
- `jetracer_ros2/cone_follow.py` : 판단부(ConeFollower, ModeMachine) + ROS 노드
- `launch/m8_simple.launch.py` : simple_lane -> cone_follow -> /cmd_vel 단독 시험 (매니저 미사용, bag 기록)
- `test/sim_cone_follow.py` : 폐루프 시뮬레이션 `python3 -I test/sim_cone_follow.py 100` (hard 옵션)

`setup.py` 의 console_scripts 에 한 줄 추가 후 colcon build:
```
'cone_follow_node = jetracer_ros2.cone_follow:main',
```

## 실행
```
ros2 launch jetracer_ros2 jetracer_teleop.launch.py      # 하드웨어 (bridge 포함)
ros2 launch jetracer_ros2 m8_simple.launch.py            # 콘 입구 앞 차로에서 시작
ros2 launch jetracer_ros2 m8_simple.launch.py start_in_cone:=true   # 콘 안에서 시작
# 인자: speed:=0.15 width:=0.50 record:=false
```
입력: /scan, inference/cmd_vel(차선), /mission/event(ESTOP/ESTOP_CLEAR)  출력: /cmd_vel (angular.z = v*k), /cone_follow/state(JSON)

## 주의
- 차체/라이다 치수는 명목값(차폭 ±0.12, 앞 0.29, 뒤 0.09, 라이다 뒤 차축 앞 0.203). 다르면 Params 수정.
- /cmd_vel -> 조향은 simple_lane bridge (atan(L*w/v)) 기준.
- 전체 주행 매니저(all_in_node)에는 아직 연결 안 됨. M8 트리거에서 이 노드를 켜는 연동 필요.
- 시뮬레이션: 기본(폭 0.42~0.60) 100/100 통과·접촉 0, hard(폭 0.40~0.48, 큰 오차) 95/100.
